

public interface IObserver {
     boolean update(Observable object);
}
