public interface IAccount{
       String getDomain();
       void setDomain(String domain);
       String getType();
       void setID(int ID);
       void setUsername(String username);
       void setPassword(String password);
       int getID();
       String getUsername();
       String getPassword();
       void setType(String accountType);
}
